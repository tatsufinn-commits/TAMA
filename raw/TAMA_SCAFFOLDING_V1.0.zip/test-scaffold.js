const fs = require('fs');
const path = require('path');

function assert(cond, msg) {
  if (!cond) {
    console.error(`❌ FAIL: ${msg}`);
    process.exit(1);
  }
  console.log(`✅ PASS: ${msg}`);
}

console.log('--- Running TAMAintegration Scaffolding Verification ---');

// 1. Verify docs suite
const requiredDocs = [
  'docs/AI_RULES.md',
  'docs/AGENTS.md',
  'docs/STUDY_LOGBOOK.md',
  'docs/STRATEGIC_ACADEMIC_FRAMEWORK.md',
  'docs/PROMPT_PLAYBOOK.md',
  'docs/ACADEMIC_CONTEXT.md',
  'docs/CODEBASE_DEEP_DIVE_STUDY.md',
  'docs/DIAGNOSTIC_AND_TESTING_GUIDE.md',
  'docs/FUTURE_BRAIN_UPGRADE_SPEC.md',
  'docs/REPAIR_DOSSIER.md'
];

requiredDocs.forEach(doc => {
  assert(fs.existsSync(doc), `Document exists: ${doc}`);
});

// 2. Verify vault folders
const requiredVaults = [
  'vault/00-CORE-BUILDING-LAWS/PD-1096-NBCP',
  'vault/00-CORE-BUILDING-LAWS/RA-9514-FIRE-CODE',
  'vault/00-CORE-BUILDING-LAWS/BP-344-ACCESSIBILITY',
  'vault/00-CORE-BUILDING-LAWS/RA-9266-SPP-DOCS',
  'vault/01-CURRENT-COURSES',
  'vault/02-HISTORY-ARCHIVE'
];

requiredVaults.forEach(vault => {
  assert(fs.existsSync(vault), `Vault directory exists: ${vault}`);
});

// 3. Verify roadmap & proposal
assert(fs.existsSync('research/directives/roadmap/MASTER_ROADMAP_TAMA_V1.0.md'), 'Master Roadmap exists in research/directives/roadmap/');
assert(fs.existsSync('research/directives/roadmap/TAMA_THEHUB_INTEGRATION_PROPOSAL_V1.0.md'), 'Integration Proposal exists in research/directives/roadmap/');

console.log('--- ALL TAMA SCAFFOLDING VERIFICATIONS PASSED (100% GREEN) ---');
process.exit(0);
